/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package beans;

public class Especies {
    
    private int id;
    private String nome;
    private String nome_cient;
    private String status;
    private String habitat;
    private String descricao;
    private int dt_registro;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome_cient() {
        return nome_cient;
    }

    public void setNome_cient(String nome_cient) {
        this.nome_cient = nome_cient;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getDt_registro() {
        return dt_registro;
    }

    public void setDt_registro(int dt_registro) {
        this.dt_registro = dt_registro;
    }
    
    
}
