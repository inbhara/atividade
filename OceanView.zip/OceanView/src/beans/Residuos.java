
package beans;

public class Residuos {
    
}
