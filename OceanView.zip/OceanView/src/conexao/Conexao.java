
package conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexao {

    // Método para obter uma conexão com o banco de dados
    public Connection getConnection() throws ClassNotFoundException {
        Connection conn = null;
        try {
            // Estabelece a conexão com o banco de dados
            conn = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/canessolution", // URL do banco de dados
                "root", // Usuário do banco
                "" // Senha do banco
            );
        } catch (SQLException e) {
            // Tratamento da exceção
            System.out.println("Erro de conexão: " + e.getMessage());
        }
        return conn;
    }
}

