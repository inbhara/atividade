package dao;

import beans.Especies;
import conexao.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EspeciesDAO {
    private Conexao conexao;
    private Connection conn;
    
    public EspeciesDAO() {
    this.conexao = new Conexao();
    this.conn = this.conexao.getConexao();
}  
    public void inserir(EspeciesDAO Especies) {
        String sql = "INSERT INTO especies (nome, status, habitat, descricao, dt_resgistro) VALUES (?,?,?,?,?)";

        try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, Especies.getNome()); 
            stmt.setString(2, Especies.getNome_cient());
            stmt.setString(3, Especies.getStatus()); 
            stmt.setString(4, Especies.getHabitat());
            stmt.setString(5, Especies.getDescricao()); 
            stmt.setInt(6, Especies.getDt_registro()); 
            stmt.setInt(7, Especies.getId()); 
            stmt.execute();
            
    } catch (SQLException e){
        System.out.println("Erro ao tentar cadastrar essa nova espécie: "+ e.getMessage());
    }
    }
    
    public void alterar(EspeciesDAO Especies){
        String sql = "UPDATE especies SET nome=?,nome_cient=?, status=?, habitat=?, descricao=?, dt_resgistro=? WHERE id=?";
        
        try {
            PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setString(1, Especies.getNome()); 
            stmt.setString(2, Especies.getNome_cient());
            stmt.setString(3, Especies.getStatus()); 
            stmt.setString(4, Especies.getHabitat());
            stmt.setString(5, Especies.getDescricao()); 
            stmt.setInt(6, Especies.getDt_registro()); 
            stmt.setInt(7, Especies.getId()); 
            stmt.execute();
            
        } catch (SQLException e) {
            System.out.println("Erro ao tentar atualizar o usuário: " + e.getMessage());
        } finally {
            try {
                if (stmt != null) {
                    stmt.close(); // Fechar o PreparedStatement
                }
                if (this.conn != null) {
                    this.conn.close(); // Fechar a conexão se apropriado
                }
            } catch (SQLException e) {
                System.out.println("Erro ao tentar atualizar usuário: " + e.getMessage());
            }
        }
    }
          public void excluir(int id) {
        String sql = "DELETE FROM especies WHERE id = ?";
    try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
            stmt.setInt(1, id);
            stmt.execute();
    } catch (SQLException e){
        System.out.println("Erro ao tentar excluir essa espécie: "+ e.getMessage());
    }
    }

    public List<Especies> getEspecies(){
            String sql = "SELECT * FROM especies";
            try{
        PreparedStatement stmt = this.conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            List<Especies> ListaEspecies = new ArrayList<>();
            while(rs.next()){
                Especies o = new Especies();
                o.setId(rs.getInt("id"));
                o.setNome(rs.getString("nome"));
                o.setNome_cient(rs.getString("nome científico"));
                o.setStatus(rs.getString("status"));
                o.setHabitat(rs.getString("habitat"));
                o.setDescricao(rs.getString("descrição"));
                o.setDt_registro(rs.getInt("data de registro"));
                ListaEspecies.add(o);
            }
        return ListaEspecies;
    } catch (SQLException e){
        return null;
                }
          }
    }
